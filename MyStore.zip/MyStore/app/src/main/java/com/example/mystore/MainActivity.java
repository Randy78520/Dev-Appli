package com.example.mystore;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    private Accelerometer accelerometer;
    private static final String TAG = "ListDataActivity";
    DatabaseHelper mDatabaseHelper;
    private ListView mListView;


    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        accelerometer = new Accelerometer(this);
        accelerometer.setListener(new Accelerometer.Listener() {
            @Override
            public void onTranslation(float tx, float ty, float tz) {
                if (tx > 2.0f) {
                    Intent i = new Intent(MainActivity.this, EnterPasswordActivity.class);
                    finish();
                    startActivity(i);
                } else if (tx < -2.0f) {
                    Intent i = new Intent(MainActivity.this, EnterPasswordActivity.class);
                    finish();
                    startActivity(i);
                }
            }


        });

        populateListView();
    }

        private void populateListView () {
            Log.d(TAG, "populateListView: affichage des données dans MainActivity.");

            // récupère les données et les ajoute à une liste
            Cursor data = mDatabaseHelper.getData();
            ArrayList<String> listData = new ArrayList<>();
            while (data.moveToNext()) {
                // récupère la valeur de la base de données dans la colonne 1
                // puis ajoutez-le à ArrayList
                listData.add(data.getString(1));
            }
            // créer l'adaptateur de liste et définir l'adaptateur
            ListAdapter adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listData);
            mListView.setAdapter(adapter);

            // définit un onItemClickListener sur ListView
            mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    String name = adapterView.getItemAtPosition(i).toString();
                    Log.d(TAG, "onItemClick: You Clicked on " + name);

                    Cursor data = mDatabaseHelper.getItemID(name); // récupère l'identifiant associé à ce nom
                    int itemID = -1;
                    while (data.moveToNext()) {
                        itemID = data.getInt(0);
                    }
                    if (itemID > -1) {
                        Log.d(TAG, "onItemClick: The ID is: " + itemID);
                        Intent editScreenIntent = new Intent(MainActivity.this, MainActivity.class);
                        editScreenIntent.putExtra("id", itemID);
                        editScreenIntent.putExtra("name", name);
                        startActivity(editScreenIntent);
                    } else {
                        toastMessage("Aucun identifiant associé à ces infos");
                    }
                }

                private void toastMessage(String s) {
                }
            });


        }
    }